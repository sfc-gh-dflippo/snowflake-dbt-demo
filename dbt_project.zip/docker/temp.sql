--!jinja
/*
Sample Usage:

CREATE OR REPLACE STAGE ${DBT_PROJECT_STAGE_NAME} ENCRYPTION = (type = 'SNOWFLAKE_SSE');
CREATE OR REPLACE STAGE ${DBT_LOG_STAGE_NAME} ENCRYPTION = (type = 'SNOWFLAKE_SSE');
COPY FILES INTO @${DBT_PROJECT_STAGE_NAME} FROM @DATABASE_NAME.SCHEMA_NAME.GIT_REPO/branches/main/;

EXECUTE IMMEDIATE FROM @dbt_script_stage
  USING (
    job_service_name => '${DBT_SERVICE_NAME}',
    dbt_commands => '${DBT_DEFAULT_COMMANDS}',
    log_folder => '/logs/${DBT_SERVICE_NAME }}',
    dbt_project_stage => '${DBT_PROJECT_STAGE_NAME}',
    dbt_log_stage => '${DBT_LOG_STAGE_NAME}'
  );

All parameters are optional and will use the defaults above

*/

drop service if exists {{ job_service_name|default("${DBT_SERVICE_NAME}", true) }};

EXECUTE JOB SERVICE
  IN COMPUTE POOL ${COMPUTE_POOL_NAME}
  NAME = {{ job_service_name|default("${DBT_SERVICE_NAME}", true) }}
  EXTERNAL_ACCESS_INTEGRATIONS = ( ${EAI_NAME} )
  QUERY_WAREHOUSE = ${DBT_QUERY_WAREHOUSE}
FROM SPECIFICATION $$
spec:
  containers:
  - name: dbt-snowpark
    image: ${IMAGE_FQN}
    args:
      - "-c"
      - "{{dbt_commands|default("${DBT_DEFAULT_COMMANDS}", true) }}"
    env:
        DBT_LOG_PATH: "{{ log_folder|default("/logs/${DBT_SERVICE_NAME }}", true) }}"
    volumeMounts:
      - name: dbt-project-source
        mountPath: /source
      - name: dbt-logs
        mountPath: /logs
  volumes:
    - name: dbt-project-source
      source: "@{{ dbt_project_stage|default("${DBT_PROJECT_STAGE_NAME}", true) }}"
    - name: dbt-logs
      source: "@{{ dbt_log_stage|default("${DBT_LOG_STAGE_NAME}", true) }}"
$$;

SELECT "SYSTEM\$GET_SERVICE_LOGS"({{ job_service_name|default("${DBT_SERVICE_NAME}", true) }}, '0', 'dbt-snowpark', 1000);
