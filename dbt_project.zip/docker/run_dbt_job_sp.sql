CREATE OR REPLACE PROCEDURE RUN_DBT_JOB(
    COMPUTE_POOL_NAME VARCHAR,
    EXTERNAL_ACCESS_INT_NAME VARCHAR,
    DBT_IMAGE_URL VARCHAR,
    dbt_commands VARCHAR DEFAULT 'dbt clean && dbt deps && dbt build',
    dbt_project_stage VARCHAR DEFAULT 'DBT_PROJECT_STAGE',
    dbt_log_stage VARCHAR DEFAULT 'DBT_LOG_STAGE',
)
RETURNS TABLE(DBT_LOG VARCHAR)
LANGUAGE SQL
AS $$
DECLARE

BEGIN
    LET TIMESTAMP_TEXT := to_char(CURRENT_TIMESTAMP(), 'YYYYMMDD_HH24MISS');
    LET JOB_SERVICE_NAME VARCHAR := 'SPCS_DBT_CORE_' || TIMESTAMP_TEXT;
    LET LOG_FOLDER VARCHAR := '/logs/spcs_dbt_core_' || to_char(CURRENT_TIMESTAMP(), 'YYYYMMDD_HH24MISS');
    LET IMAGE_URL := '/dflippo_dev_db/public/images/spcs_dbt_core';

EXECUTE IMMEDIATE 'DROP SERVICE IF EXISTS ' || JOB_SERVICE_NAME;

BEGIN
    EXECUTE IMMEDIATE '
    EXECUTE JOB SERVICE
    IN COMPUTE POOL DFLIPPO_DBT_CORE_COMPUTE_POOL
    NAME = '||JOB_SERVICE_NAME||'
    EXTERNAL_ACCESS_INTEGRATIONS = ( DFLIPPO_DBT_ACCESS_INT )
    QUERY_WAREHOUSE = '||CURRENT_WAREHOUSE()||'
    FROM SPECIFICATION $$
    spec:
    containers:
    - name: dbt-snowpark
        image: '||DBT_IMAGE_URL||'
        args:
        - "-c"
        - "'||dbt_commands||'"
        env:
            DBT_LOG_PATH: "'||LOG_FOLDER||'"
        volumeMounts:
        - name: dbt-project-source
            mountPath: /source
        - name: dbt-logs
            mountPath: /logs
    volumes:
        - name: dbt-project-source
        source: "@{{ dbt_project_stage|default("dbt_project_stage", true) }}"
        - name: dbt-logs
        source: "@{{ dbt_log_stage|default("dbt_log_stage", true) }}"
    $$
    ';
-- We will return the log whether it runs or fails
EXCEPTION WHEN OTHER THEN
    NULL;
END;

RETURN (SELECT "SYSTEM$GET_SERVICE_LOGS"({{ job_service_name|default("spcs_dbt_core", true) }}, '0', 'dbt-snowpark', 1000));

END;
$$;
