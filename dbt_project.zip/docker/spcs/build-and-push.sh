#!/bin/bash

set -e

export DB_NAME="DFLIPPO_DEV_DB"
export SNOWFLAKE_DEFAULT_CONNECTION_NAME="default"
export SCHEMA_NAME="public"
export IMAGE_REPO_NAME="images"
export DBT_SCRIPT_STAGE_NAME="dbt_script_stage"
export DBT_PROJECT_STAGE_NAME="dbt_project_stage"
export DBT_LOG_STAGE_NAME="dbt_log_stage"
export DBT_DEFAULT_COMMANDS="dbt clean && dbt deps && dbt build"
export DBT_SERVICE_NAME="spcs_dbt_core"
export DIR_NAME="./service"
export COMPUTE_POOL_NAME=DFLIPPO_DBT_CORE_COMPUTE_POOL
export EAI_NAME=DFLIPPO_DBT_ACCESS_INT
export DBT_QUERY_WAREHOUSE=DFLIPPO_WH

snow connection test

# make sure the target repository exists
snow sql -i <<EOF
create database if not exists ${DB_NAME};
create schema if not exists ${DB_NAME}.${SCHEMA_NAME};
create image repository if not exists ${DB_NAME}.${SCHEMA_NAME}.${IMAGE_REPO_NAME};
create stage if not exists ${DB_NAME}.${SCHEMA_NAME}.${DBT_LOG_STAGE_NAME} ENCRYPTION = (type = 'SNOWFLAKE_SSE');
create stage if not exists ${DB_NAME}.${SCHEMA_NAME}.${DBT_PROJECT_STAGE_NAME} ENCRYPTION = (type = 'SNOWFLAKE_SSE');
EOF

export IMAGE_REPO_URL=$(snow spcs image-repository url $IMAGE_REPO_NAME --database $DB_NAME --schema $SCHEMA_NAME)
export IMAGE_FQN="${IMAGE_REPO_URL}/${DBT_SERVICE_NAME}"

# build and push the image (uses :latest implicitly)
snow spcs image-registry login
docker buildx build --platform=linux/amd64 --pull --push -t $IMAGE_FQN $DIR_NAME

echo "The container image and execute scripts are now installed."

cat <<EOF > sample_run_dbt.sql
--  Sample Usage --

RM @${DBT_PROJECT_STAGE_NAME};
COPY FILES INTO @${DBT_PROJECT_STAGE_NAME} FROM @DATABASE_NAME.SCHEMA_NAME.GIT_REPO/branches/main/;

drop service if exists ${DBT_SERVICE_NAME};

EXECUTE JOB SERVICE
    IN COMPUTE POOL ${COMPUTE_POOL_NAME}
    NAME = ${DBT_SERVICE_NAME}
    EXTERNAL_ACCESS_INTEGRATIONS = ( ${EAI_NAME} )
    QUERY_WAREHOUSE = ${DBT_QUERY_WAREHOUSE}
FROM SPECIFICATION \$\$
spec:
  containers:
  - name: dbt-snowpark
    image: ${IMAGE_FQN}
    args:
      - "-c"
      - "${DBT_DEFAULT_COMMANDS}"
    env:
        DBT_LOG_PATH: "/logs/${DBT_SERVICE_NAME}"
    volumeMounts:
      - name: dbt-project-source
        mountPath: /source
      - name: dbt-logs
        mountPath: /logs
  volumes:
    - name: dbt-project-source
      source: "@${DBT_PROJECT_STAGE_NAME}"
    - name: dbt-logs
      source: "@${DBT_LOG_STAGE_NAME}"
\$\$;

SELECT "SYSTEM\$GET_SERVICE_LOGS"('${DBT_SERVICE_NAME}', '0', 'dbt-snowpark', 1000);

EOF
cat sample_run_dbt.sql
