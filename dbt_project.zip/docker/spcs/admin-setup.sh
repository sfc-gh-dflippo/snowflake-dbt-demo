#!/bin/bash

set -e

export DB_NAME=DFLIPPO_DEV_DB
export SCHEMA_NAME=public
export NETWORK_RULE_NAME=DBT_NETWORK_RULE
export COMPUTE_POOL_NAME=DFLIPPO_DBT_CORE_COMPUTE_POOL
export EAI_NAME=DFLIPPO_DBT_ACCESS_INT

# make sure the target repository exists
snow sql -i <<EOF
create database if not exists ${DB_NAME};
create schema if not exists ${DB_NAME}.${SCHEMA_NAME};

CREATE NETWORK RULE IF NOT EXISTS ${DB_NAME}.${SCHEMA_NAME}.${NETWORK_RULE_NAME}
  MODE = EGRESS
  TYPE = HOST_PORT
  VALUE_LIST = (
    'github.com',
    'api.github.com',
    'hub.getdbt.com',
    'codeload.github.com');

CREATE EXTERNAL ACCESS INTEGRATION IF NOT EXISTS ${EAI_NAME}
  ALLOWED_NETWORK_RULES = (${DB_NAME}.${SCHEMA_NAME}.${NETWORK_RULE_NAME})
  ENABLED = true;

CREATE COMPUTE POOL IF NOT EXISTS ${COMPUTE_POOL_NAME}
    MIN_NODES = 1
    MAX_NODES = 1
    INSTANCE_FAMILY = CPU_X64_S;

EOF


