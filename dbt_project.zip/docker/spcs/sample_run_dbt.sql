--  Sample Usage --

RM @dbt_project_stage;
COPY FILES INTO @dbt_project_stage FROM @DATABASE_NAME.SCHEMA_NAME.GIT_REPO/branches/main/;

drop service if exists spcs_dbt_core;

EXECUTE JOB SERVICE
    IN COMPUTE POOL DFLIPPO_DBT_CORE_COMPUTE_POOL
    NAME = spcs_dbt_core
    EXTERNAL_ACCESS_INTEGRATIONS = ( DFLIPPO_DBT_ACCESS_INT )
    QUERY_WAREHOUSE = DFLIPPO_WH
FROM SPECIFICATION $$
spec:
  containers:
  - name: dbt-snowpark
    image: sfpscogs-aws-cas2.registry.snowflakecomputing.com/dflippo_dev_db/public/images/spcs_dbt_core
    args:
      - "-c"
      - "dbt clean && dbt deps && dbt build"
    env:
        DBT_LOG_PATH: "/logs/spcs_dbt_core"
    volumeMounts:
      - name: dbt-project-source
        mountPath: /source
      - name: dbt-logs
        mountPath: /logs
  volumes:
    - name: dbt-project-source
      source: "@dbt_project_stage"
    - name: dbt-logs
      source: "@dbt_log_stage"
$$;

SELECT "SYSTEM$GET_SERVICE_LOGS"('spcs_dbt_core', '0', 'dbt-snowpark', 1000);

