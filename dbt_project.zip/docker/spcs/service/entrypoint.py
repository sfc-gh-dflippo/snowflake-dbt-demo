#!/usr/bin/env python

from snowflake.snowpark import Session
from datetime import datetime
import sys
import os
import shutil


def get_login_token():
    with open('/snowflake/session/token', 'r') as f:
        return f.read()


def copy_all(src, dst):
    if not os.path.exists(dst):
        os.makedirs(dst)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)


def write_config_files():
    import toml
    home_dir = os.getenv('HOME')
    snowflake_home_dir = os.getenv('SNOWFLAKE_HOME')
    # Use the snowflake home if available
    if snowflake_home_dir != None:
        config_toml = os.path.join(snowflake_home_dir, "config.toml")
        connections_toml = os.path.join(snowflake_home_dir, "connections.toml")
    else:
        config_toml = os.path.join(home_dir, ".snowflake", "config.toml")
        connections_toml = os.path.join(
            home_dir, ".snowflake", "connections.toml")
        snowflake_home_dir = os.path.join(home_dir, ".snowflake")
        os.environ['SNOWFLAKE_HOME'] = snowflake_home_dir

    if not os.path.exists(snowflake_home_dir):
        os.makedirs(snowflake_home_dir)
    os.chmod(snowflake_home_dir, 0o700)

    with open(config_toml, 'w') as f:
        toml.dump({"default_connection_name": "default"}, f)
    os.chmod(config_toml, 0o600)

    connections = {
        "default": {
            "authenticator": 'oauth',
            "account": os.getenv('SNOWFLAKE_ACCOUNT'),
            "host": os.getenv('SNOWFLAKE_HOST'),
            "token": get_login_token(),
            "token_file_path": "/snowflake/session/token",
            "database": os.getenv('SNOWFLAKE_DATABASE'),
            "schema": os.getenv('SNOWFLAKE_SCHEMA'),
            "user": os.getenv('SNOWFLAKE_USER'),
            "role": os.getenv('SNOWFLAKE_ROLE'),
            "warehouse": os.getenv('SNOWFLAKE_WAREHOUSE'),
            "CLIENT_SESSION_KEEP_ALIVE": "true"
        }
    }
    with open(connections_toml, 'w') as f:
        toml.dump(connections, f)
    os.chmod(connections_toml, 0o600)
    os.environ['SNOWFLAKE_DEFAULT_CONNECTION_NAME'] = "default"


# Lookup environment variables
account = os.getenv('SNOWFLAKE_ACCOUNT')
host = os.getenv('SNOWFLAKE_HOST')
source_directory = os.getenv('DBT_PROJECT_SOURCE_DIR')
destination_directory = os.getenv('DBT_PROJECT_DIR')

# Copy all the source project files to our working directory
copy_all(source_directory, destination_directory)

# Open a connection to get the current user, role, and warehouse
session = Session.builder.configs({
    "account": account,
    "host": host,
    "token": get_login_token(),
    "authenticator": 'oauth'
}).create()

# Set environment variables
os.environ['SNOWFLAKE_USER'] = session.get_current_user().strip('"')
os.environ['SNOWFLAKE_ROLE'] = session.get_current_role().strip('"')
os.environ['SNOWFLAKE_WAREHOUSE'] = session.get_current_warehouse().strip('"')
os.environ['DBT_ENV_SECRET_OAUTH_TOKEN'] = get_login_token()
os.environ['DBT_LOG_PATH'] = os.path.join(
    "/logs", os.environ['SNOWFLAKE_USER'] + "_" + datetime.now().strftime("%Y%m%d_%H%M%S"))

session.close()

write_config_files()

# We will pass all our arguments to the shell to run
subproc = sys.argv
subproc[0] = "/bin/sh"

os.execvp(subproc[0], subproc)
